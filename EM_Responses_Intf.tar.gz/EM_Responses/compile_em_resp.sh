mpif90 -O3 -fallow-argument-mismatch  mathtool.f90 mympi.f90  nform_mod.f90 currents_opt_v2.f90 mc_module_em2b_sf_resp.f90 main_em2b_resp.f90
